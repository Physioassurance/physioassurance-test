#!/bin/bash

echo ""
echo "========================================"
echo "   PHYSIOASSURANCE - QUICK START"
echo "========================================"
echo ""
echo "This will set up and start your website..."
echo ""
read -p "Press Enter to continue..."

echo "Installing dependencies..."
npm run setup

echo ""
echo "Starting the website..."
echo ""
echo "Your website will open at: http://localhost:5173"
echo ""
npm run dev:full