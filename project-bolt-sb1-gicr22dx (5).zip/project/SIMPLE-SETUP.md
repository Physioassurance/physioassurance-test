# 🏥 Physioassurance - Simple Setup Guide

## What You Need First
1. **Download Node.js** from https://nodejs.org (choose the green "LTS" button)
2. **Install it** by double-clicking the downloaded file
3. **Restart your computer** after installation

## Step 1: Open Your Project
1. **Extract the zip file** you downloaded
2. **Open the folder** called `physioassurance-website`
3. **Right-click in the empty space** inside the folder
4. **Choose "Open in Terminal"** or "Open Command Prompt here"
   - On Windows: Hold Shift + Right-click → "Open PowerShell window here"
   - On Mac: Right-click → "New Terminal at Folder"

## Step 2: Install Everything (One Command!)
Copy and paste this command, then press Enter:
```
npm run setup
```
**Wait for it to finish** (it might take 2-3 minutes)

## Step 3: Start the Website
Copy and paste this command, then press Enter:
```
npm run dev:full
```

## Step 4: Open Your Website
1. **Wait** until you see messages like "Local: http://localhost:5173"
2. **Open your web browser** (Chrome, Firefox, etc.)
3. **Go to**: http://localhost:5173

## 🎉 That's It!
Your website should now be running! You'll see the Physioassurance homepage.

---

## If Something Goes Wrong

### Problem: "npm is not recognized" or "command not found"
**Solution**: You need to install Node.js first (see "What You Need First" above)

### Problem: "Port already in use"
**Solution**: Copy and paste this, then try again:
```
npx kill-port 5173 5000
```

### Problem: Website shows errors
**Solution**: 
1. Close the terminal window
2. Open a new terminal in the project folder
3. Run these commands one by one:
```
npm install
npm run dev:full
```

### Problem: Still not working?
1. **Delete these folders** if they exist: `node_modules`, `server/node_modules`
2. **Run this command**:
```
npm run setup
```
3. **Then run**:
```
npm run dev:full
```

---

## What Each Part Does
- **Frontend** (http://localhost:5173): The website users see
- **Backend** (http://localhost:5000): The server that handles data

## To Stop the Website
Press `Ctrl + C` in the terminal window (or `Cmd + C` on Mac)

## To Start Again Later
1. Open terminal in the project folder
2. Run: `npm run dev:full`