import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Search, Calendar, MessageCircle, Shield } from 'lucide-react';

const SubscriberPage: React.FC = () => {
  return (
    <>
      {/* Hero section */}
      <section className="pt-32 pb-16 md:pb-24 bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-6"
            >
              Find the Perfect Physiotherapist Near You
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-xl text-blue-100 mb-8"
            >
              Connect with qualified physiotherapists in your area and start your recovery journey today.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4"
            >
              <Link 
                to="#subscription-plans" 
                className="inline-flex items-center justify-center rounded-md bg-white px-6 py-3 text-base font-medium text-blue-600 shadow-sm hover:bg-gray-100 transition-colors focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-600"
              >
                View Plans
              </Link>
              <Link 
                to="#how-it-works" 
                className="inline-flex items-center justify-center rounded-md border border-white px-6 py-3 text-base font-medium text-white hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-600"
              >
                Learn More
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Benefits section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              Why Choose Physioassurance?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Experience the benefits of our platform for your physiotherapy needs
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Search className="h-10 w-10 text-blue-600" />,
                title: "Find Qualified Professionals",
                description: "Access a network of verified physiotherapists with diverse specializations."
              },
              {
                icon: <Calendar className="h-10 w-10 text-blue-600" />,
                title: "Easy Appointment Booking",
                description: "Book appointments at your convenience with our user-friendly system."
              },
              {
                icon: <MessageCircle className="h-10 w-10 text-blue-600" />,
                title: "Direct Communication",
                description: "Chat directly with your physiotherapist for better care coordination."
              },
              {
                icon: <Shield className="h-10 w-10 text-blue-600" />,
                title: "Quality Assurance",
                description: "All physiotherapists are verified and reviewed for your safety."
              }
            ].map((benefit, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-lg shadow-md text-center"
              >
                <div className="flex justify-center mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              How It Works
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Connect with physiotherapists in just a few simple steps
            </motion.p>
          </div>

          <div className="max-w-4xl mx-auto">
            {[
              {
                step: 1,
                title: "Create Your Account",
                description: "Sign up and create your personal account with your basic information."
              },
              {
                step: 2,
                title: "Search for Physiotherapists",
                description: "Browse through our directory of qualified physiotherapists in your area."
              },
              {
                step: 3,
                title: "Book an Appointment",
                description: "Select a physiotherapist and book an appointment at your preferred time."
              },
              {
                step: 4,
                title: "Receive Quality Care",
                description: "Visit your physiotherapist and get the treatment you need."
              }
            ].map((step, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`flex items-start mb-12 ${index % 2 !== 0 ? 'flex-row-reverse' : ''}`}
              >
                <div className="flex-shrink-0 mr-6 ml-6">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-600 text-white font-bold text-lg">
                    {step.step}
                  </div>
                </div>
                <div className={`flex-grow ${index % 2 !== 0 ? 'text-right' : ''}`}>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Subscription plans */}
      <section id="subscription-plans" className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              Subscription Plans
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Choose a plan that fits your healthcare needs
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "Basic",
                price: "₹499",
                period: "per month",
                description: "Perfect for occasional needs",
                features: [
                  "2 appointments per month",
                  "Access to basic search",
                  "Email support",
                  "Limited provider options"
                ]
              },
              {
                name: "Standard",
                price: "₹499",
                period: "per month",
                description: "Most popular for regular care",
                features: [
                  "5 appointments per month",
                  "Advanced search filters",
                  "Priority booking",
                  "Chat with physiotherapists",
                  "Phone & email support"
                ],
                featured: true
              },
              {
                name: "Premium",
                price: "₹999",
                period: "per month",
                description: "For comprehensive care needs",
                features: [
                  "Unlimited appointments",
                  "Home visit options",
                  "24/7 support access",
                  "Family account (up to 4 members)",
                  "Exclusive health resources"
                ]
              }
            ].map((plan, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`rounded-lg overflow-hidden ${
                  plan.featured 
                    ? 'shadow-xl ring-2 ring-blue-600 transform md:-translate-y-4' 
                    : 'shadow-md'
                }`}
              >
                <div className={`p-6 ${plan.featured ? 'bg-blue-600 text-white' : 'bg-white text-gray-900'}`}>
                  <h3 className="text-2xl font-bold mb-1">{plan.name}</h3>
                  <p className={plan.featured ? 'text-blue-100' : 'text-gray-600'}>
                    {plan.description}
                  </p>
                  <div className="mt-4 mb-6">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className={`ml-2 ${plan.featured ? 'text-blue-100' : 'text-gray-500'}`}>
                      {plan.period}
                    </span>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link 
                    to="#" 
                    className={`block w-full text-center py-3 rounded-md ${
                      plan.featured 
                        ? 'bg-blue-600 text-white hover:bg-blue-700' 
                        : 'bg-white border border-blue-600 text-blue-600 hover:bg-blue-50'
                    } transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2`}
                  >
                    Subscribe Now
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24 bg-blue-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              Success Stories
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Read about the experiences of our satisfied subscribers
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                quote: "After my sports injury, finding the right physiotherapist was crucial. Physioassurance made it incredibly easy to connect with a specialist who understood my needs. I've now fully recovered and back to playing football!",
                name: "Rahul Singh",
                title: "Football Player",
                image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1600"
              },
              {
                quote: "As someone with chronic back pain, I needed regular physiotherapy sessions. The Standard plan gave me the flexibility to book appointments whenever I needed, and the quality of care has been exceptional.",
                name: "Priya Sharma",
                title: "IT Professional",
                image: "https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=1600"
              }
            ].map((testimonial, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <p className="text-gray-600 italic mb-6">"{testimonial.quote}"</p>
                <div className="flex items-center">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="h-12 w-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <p className="font-medium text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.title}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              Frequently Asked Questions
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Find answers to common questions about our services
            </motion.p>
          </div>

          <div className="max-w-3xl mx-auto">
            {[
              {
                question: "How do I find a physiotherapist in my area?",
                answer: "After creating an account, you can use our search feature to find physiotherapists in your area. You can filter by location, specialization, availability, and more to find the perfect match for your needs."
              },
              {
                question: "Can I change my subscription plan?",
                answer: "Yes, you can upgrade or downgrade your subscription plan at any time. Changes will be applied at the start of your next billing cycle."
              },
              {
                question: "What if I need to cancel an appointment?",
                answer: "You can cancel or reschedule appointments through your account dashboard up to 24 hours before the scheduled time without any penalty."
              },
              {
                question: "Are the physiotherapists qualified?",
                answer: "Yes, all physiotherapists on our platform are verified professionals with valid qualifications and registrations. We thoroughly check their credentials before allowing them to join our network."
              },
              {
                question: "Can I use my health insurance with Physioassurance?",
                answer: "Yes, many health insurance providers cover physiotherapy services. You can download invoices from your account to submit to your insurance company for reimbursement."
              }
            ].map((faq, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="mb-6"
              >
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to action */}
      <section className="py-16 md:py-24 bg-blue-600">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-white mb-6"
            >
              Start Your Recovery Journey Today
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-xl text-blue-100 mb-8"
            >
              Join thousands of satisfied subscribers who have found the perfect physiotherapist through our platform.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <Link 
                to="#subscription-plans" 
                className="inline-flex items-center justify-center rounded-md bg-white px-6 py-3 text-base font-medium text-blue-600 shadow-sm hover:bg-gray-100 transition-colors focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-600"
              >
                Subscribe Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default SubscriberPage;