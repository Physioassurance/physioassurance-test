import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight } from 'lucide-react';

const PhysiotherapistPage: React.FC = () => {
  return (
    <>
      {/* Hero section */}
      <section className="pt-32 pb-16 md:pb-24 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-6"
            >
              Join Our Network of Expert Physiotherapists
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-xl text-blue-100 mb-8"
            >
              Expand your practice, connect with more patients, and grow your professional network.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Link 
                to="/register" 
                className="inline-flex items-center justify-center rounded-md bg-white px-6 py-3 text-base font-medium text-blue-600 shadow-sm hover:bg-gray-100 transition-colors focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-600"
              >
                Register Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Benefits section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              Why Join Physioassurance?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Enjoy numerous benefits when you become a part of our growing network
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Increased Visibility",
                description: "Get listed in our directory and be discovered by patients looking for your expertise in your area."
              },
              {
                title: "Streamlined Appointments",
                description: "Our booking system makes it easy for patients to schedule appointments, reducing administrative work."
              },
              {
                title: "Professional Profile",
                description: "Showcase your qualifications, experience, and specialties with a professional online profile."
              },
              {
                title: "Patient Reviews",
                description: "Build your reputation through verified patient reviews and ratings."
              },
              {
                title: "Flexible Schedule",
                description: "Set your own availability and manage your calendar according to your preferences."
              },
              {
                title: "Secure Payments",
                description: "Receive payments securely through our integrated payment system."
              }
            ].map((benefit, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  {benefit.title}
                </h3>
                <p className="text-gray-600">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              How It Works
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Join our platform in just a few simple steps
            </motion.p>
          </div>

          <div className="max-w-4xl mx-auto">
            {[
              {
                step: 1,
                title: "Create Your Profile",
                description: "Register and create your professional profile with your qualifications, experience, and expertise."
              },
              {
                step: 2,
                title: "Set Your Schedule",
                description: "Define your working hours and availability for appointments."
              },
              {
                step: 3,
                title: "Get Verified",
                description: "Our team verifies your credentials to ensure quality and trust."
              },
              {
                step: 4,
                title: "Start Receiving Patients",
                description: "Once approved, your profile goes live and patients can book appointments with you."
              }
            ].map((step, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`flex items-start mb-12 ${index % 2 !== 0 ? 'flex-row-reverse' : ''}`}
              >
                <div className="flex-shrink-0 mr-6 ml-6">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-600 text-white font-bold text-lg">
                    {step.step}
                  </div>
                </div>
                <div className={`flex-grow ${index % 2 !== 0 ? 'text-right' : ''}`}>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              Simple, Transparent Pricing
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Choose the plan that works best for your practice
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "Basic",
                price: "₹499",
                period: "per month",
                description: "Perfect for independent practitioners",
                features: [
                  "Profile listing",
                  "5 appointments per day",
                  "Basic analytics",
                  "Email support"
                ]
              },
              {
                name: "Professional",
                price: "₹999",
                period: "per month",
                description: "Ideal for established practitioners",
                features: [
                  "Featured profile listing",
                  "Unlimited appointments",
                  "Detailed analytics",
                  "Priority email & phone support",
                  "Customizable availability"
                ],
                featured: true
              },
              {
                name: "Clinic",
                price: "₹1,999",
                period: "per month",
                description: "For clinics with multiple practitioners",
                features: [
                  "Multiple practitioner profiles",
                  "Clinic management dashboard",
                  "Advanced analytics & reporting",
                  "Dedicated account manager",
                  "Custom branding options"
                ]
              }
            ].map((plan, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`rounded-lg overflow-hidden ${
                  plan.featured 
                    ? 'shadow-xl ring-2 ring-blue-600 transform md:-translate-y-4' 
                    : 'shadow-md'
                }`}
              >
                <div className={`p-6 ${plan.featured ? 'bg-blue-600 text-white' : 'bg-white text-gray-900'}`}>
                  <h3 className="text-2xl font-bold mb-1">{plan.name}</h3>
                  <p className={plan.featured ? 'text-blue-100' : 'text-gray-600'}>
                    {plan.description}
                  </p>
                  <div className="mt-4 mb-6">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className={`ml-2 ${plan.featured ? 'text-blue-100' : 'text-gray-500'}`}>
                      {plan.period}
                    </span>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link 
                    to="/register" 
                    className={`block w-full text-center py-3 rounded-md ${
                      plan.featured 
                        ? 'bg-blue-600 text-white hover:bg-blue-700' 
                        : 'bg-white border border-blue-600 text-blue-600 hover:bg-blue-50'
                    } transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2`}
                  >
                    Get Started
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            >
              Frequently Asked Questions
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Find answers to common questions about joining our platform
            </motion.p>
          </div>

          <div className="max-w-3xl mx-auto">
            {[
              {
                question: "How do I join Physioassurance as a physiotherapist?",
                answer: "Simply click on the 'Register Now' button, fill out the registration form with your details, upload your qualifications and certifications, and our team will review your application. Once approved, you'll be able to set up your profile and start receiving bookings."
              },
              {
                question: "What qualifications do I need to join?",
                answer: "You need to have a valid degree in physiotherapy from a recognized institution and be registered with the relevant physiotherapy council or association. You'll need to provide proof of these qualifications during registration."
              },
              {
                question: "How much does it cost to join?",
                answer: "We offer different subscription plans starting from ₹999 per month. You can choose the plan that best suits your practice needs. Check our pricing section for more details."
              },
              {
                question: "How do I receive payments for my services?",
                answer: "Payments are processed through our secure payment system. Patients can pay online at the time of booking or after the appointment. We transfer the funds to your designated bank account after deducting our service fee."
              },
              {
                question: "Can I specify my availability?",
                answer: "Yes, you have full control over your availability. You can set your working hours, block out time for breaks or personal appointments, and update your schedule at any time."
              }
            ].map((faq, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="mb-6"
              >
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to action */}
      <section className="py-16 md:py-24 bg-blue-600">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold text-white mb-6"
            >
              Ready to Grow Your Practice?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-xl text-blue-100 mb-8"
            >
              Join our community of professional physiotherapists and expand your reach.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <Link 
                to="/register" 
                className="inline-flex items-center justify-center rounded-md bg-white px-6 py-3 text-base font-medium text-blue-600 shadow-sm hover:bg-gray-100 transition-colors focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-600"
              >
                Register Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default PhysiotherapistPage;