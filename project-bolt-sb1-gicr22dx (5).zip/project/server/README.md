# Physioassurance Backend API

A comprehensive backend API for the Physioassurance platform built with Node.js, Express, and Supabase.

## Features

- **User Authentication & Authorization**
  - JWT-based authentication
  - Role-based access control (subscribers, physiotherapists, admin)
  - Secure password hashing with bcrypt

- **User Management**
  - User registration and login
  - Profile management
  - Password change functionality

- **Physiotherapist Management**
  - Physiotherapist profile creation and management
  - Approval workflow for new physiotherapists
  - Availability management
  - Search and filtering capabilities

- **Appointment System**
  - Appointment booking and management
  - Status tracking (pending, confirmed, cancelled, completed)
  - Availability checking
  - Appointment history

- **Subscription Management**
  - Multiple subscription plans
  - Subscription creation, renewal, and cancellation
  - Payment tracking

- **Review System**
  - Patient reviews and ratings
  - Review management (CRUD operations)
  - Average rating calculations

- **File Upload**
  - Profile photo uploads
  - Document uploads for physiotherapists
  - Cloudinary integration for image storage

- **Email Notifications**
  - Welcome emails
  - Appointment confirmations
  - Appointment reminders
  - Approval notifications

## Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: Supabase (PostgreSQL)
- **Authentication**: JWT
- **File Storage**: Cloudinary
- **Email**: Nodemailer
- **Validation**: Joi
- **Security**: Helmet, CORS, Rate Limiting

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- Supabase account
- Cloudinary account (for file uploads)
- Email service (Gmail, etc.)

### Installation

1. Clone the repository and navigate to the server directory:
   ```bash
   cd server
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file based on `.env.example`:
   ```bash
   cp .env.example .env
   ```

4. Configure your environment variables in `.env`:
   - Supabase credentials
   - JWT secret
   - Cloudinary credentials
   - Email service credentials

5. Set up the database:
   - Run the migration files in your Supabase dashboard
   - Or use the Supabase CLI to apply migrations

6. Start the development server:
   ```bash
   npm run dev
   ```

The server will start on `http://localhost:5000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `POST /api/auth/logout` - User logout

### Users
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `PUT /api/users/change-password` - Change password
- `DELETE /api/users/account` - Delete account

### Physiotherapists
- `GET /api/physiotherapists` - Get all physiotherapists (with filters)
- `GET /api/physiotherapists/:id` - Get physiotherapist by ID
- `PUT /api/physiotherapists/profile` - Update physiotherapist profile
- `GET /api/physiotherapists/:id/availability` - Get availability

### Appointments
- `POST /api/appointments` - Create appointment
- `GET /api/appointments/my-appointments` - Get user appointments
- `GET /api/appointments/:id` - Get appointment by ID
- `PATCH /api/appointments/:id/status` - Update appointment status

### Reviews
- `POST /api/reviews` - Create review
- `GET /api/reviews/physiotherapist/:id` - Get reviews for physiotherapist
- `GET /api/reviews/my-reviews` - Get user's reviews
- `PUT /api/reviews/:id` - Update review
- `DELETE /api/reviews/:id` - Delete review

### Subscriptions
- `GET /api/subscriptions/plans` - Get subscription plans
- `POST /api/subscriptions` - Create subscription
- `GET /api/subscriptions/my-subscription` - Get user subscription
- `PATCH /api/subscriptions/cancel` - Cancel subscription
- `POST /api/subscriptions/renew` - Renew subscription

### File Upload
- `POST /api/upload/profile-photo` - Upload profile photo
- `POST /api/upload/documents` - Upload documents
- `DELETE /api/upload/:publicId` - Delete uploaded file

## Database Schema

The application uses the following main tables:

- **users** - User accounts (subscribers, physiotherapists, admin)
- **physiotherapist_profiles** - Extended profile data for physiotherapists
- **subscription_plans** - Available subscription plans
- **subscriptions** - User subscriptions
- **appointments** - Appointment bookings
- **reviews** - Patient reviews for physiotherapists

## Security Features

- **Row Level Security (RLS)** - Database-level security policies
- **JWT Authentication** - Secure token-based authentication
- **Password Hashing** - bcrypt for secure password storage
- **Rate Limiting** - Protection against brute force attacks
- **Input Validation** - Joi schema validation
- **CORS Protection** - Cross-origin request security
- **Helmet** - Security headers

## Error Handling

The API includes comprehensive error handling with:
- Structured error responses
- Proper HTTP status codes
- Detailed error messages in development
- Sanitized error messages in production

## Testing

Run tests with:
```bash
npm test
```

## Deployment

The backend can be deployed to various platforms:
- Heroku
- Railway
- DigitalOcean App Platform
- AWS Elastic Beanstalk
- Vercel (for serverless deployment)

Make sure to:
1. Set all environment variables
2. Configure the database connection
3. Set up file storage (Cloudinary)
4. Configure email service

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.