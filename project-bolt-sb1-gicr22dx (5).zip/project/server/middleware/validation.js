import Joi from 'joi';

export const validate = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    
    if (error) {
      return res.status(400).json({
        status: 'error',
        message: 'Validation error',
        details: error.details.map(detail => detail.message)
      });
    }
    
    next();
  };
};

// Validation schemas
export const schemas = {
  register: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    phone: Joi.string().required(),
    role: Joi.string().valid('subscriber', 'physiotherapist').required(),
    address: Joi.string().when('role', {
      is: 'physiotherapist',
      then: Joi.required(),
      otherwise: Joi.optional()
    }),
    city: Joi.string().when('role', {
      is: 'physiotherapist',
      then: Joi.required(),
      otherwise: Joi.optional()
    }),
    state: Joi.string().when('role', {
      is: 'physiotherapist',
      then: Joi.required(),
      otherwise: Joi.optional()
    }),
    specialization: Joi.string().when('role', {
      is: 'physiotherapist',
      then: Joi.required(),
      otherwise: Joi.optional()
    }),
    experience: Joi.number().when('role', {
      is: 'physiotherapist',
      then: Joi.required(),
      otherwise: Joi.optional()
    }),
    qualifications: Joi.string().when('role', {
      is: 'physiotherapist',
      then: Joi.required(),
      otherwise: Joi.optional()
    }),
    bio: Joi.string().when('role', {
      is: 'physiotherapist',
      then: Joi.required(),
      otherwise: Joi.optional()
    })
  }),

  login: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required()
  }),

  appointment: Joi.object({
    physiotherapistId: Joi.string().uuid().required(),
    appointmentDate: Joi.date().iso().required(),
    appointmentTime: Joi.string().required(),
    notes: Joi.string().optional(),
    type: Joi.string().valid('consultation', 'treatment', 'follow-up').required()
  }),

  review: Joi.object({
    appointmentId: Joi.string().uuid().required(),
    rating: Joi.number().min(1).max(5).required(),
    comment: Joi.string().required()
  })
};