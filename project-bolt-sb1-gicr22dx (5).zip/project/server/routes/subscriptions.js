import express from 'express';
import { supabase } from '../config/database.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// Get subscription plans
router.get('/plans', async (req, res) => {
  try {
    const { data: plans, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('is_active', true)
      .order('price', { ascending: true });

    if (error) throw error;

    res.json({
      status: 'success',
      data: { plans }
    });
  } catch (error) {
    console.error('Get plans error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch subscription plans'
    });
  }
});

// Create subscription
router.post('/', authenticate, authorize('subscriber'), async (req, res) => {
  try {
    const userId = req.user.id;
    const { planId, paymentMethod } = req.body;

    // Check if plan exists
    const { data: plan, error: planError } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('id', planId)
      .eq('is_active', true)
      .single();

    if (planError || !plan) {
      return res.status(404).json({
        status: 'error',
        message: 'Subscription plan not found'
      });
    }

    // Check if user already has an active subscription
    const { data: existingSubscription } = await supabase
      .from('subscriptions')
      .select('id')
      .eq('user_id', userId)
      .eq('status', 'active')
      .single();

    if (existingSubscription) {
      return res.status(409).json({
        status: 'error',
        message: 'User already has an active subscription'
      });
    }

    // Calculate subscription dates
    const startDate = new Date();
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 1); // 1 month subscription

    // Create subscription
    const { data: subscription, error } = await supabase
      .from('subscriptions')
      .insert({
        user_id: userId,
        plan_id: planId,
        status: 'active',
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        payment_method: paymentMethod,
        amount_paid: plan.price
      })
      .select(`
        *,
        subscription_plans(*)
      `)
      .single();

    if (error) throw error;

    res.status(201).json({
      status: 'success',
      message: 'Subscription created successfully',
      data: { subscription }
    });
  } catch (error) {
    console.error('Create subscription error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to create subscription'
    });
  }
});

// Get user subscription
router.get('/my-subscription', authenticate, authorize('subscriber'), async (req, res) => {
  try {
    const userId = req.user.id;

    const { data: subscription, error } = await supabase
      .from('subscriptions')
      .select(`
        *,
        subscription_plans(*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned"
      throw error;
    }

    res.json({
      status: 'success',
      data: { subscription: subscription || null }
    });
  } catch (error) {
    console.error('Get subscription error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch subscription'
    });
  }
});

// Cancel subscription
router.patch('/cancel', authenticate, authorize('subscriber'), async (req, res) => {
  try {
    const userId = req.user.id;

    // Get active subscription
    const { data: subscription, error: getError } = await supabase
      .from('subscriptions')
      .select('id, status')
      .eq('user_id', userId)
      .eq('status', 'active')
      .single();

    if (getError || !subscription) {
      return res.status(404).json({
        status: 'error',
        message: 'No active subscription found'
      });
    }

    // Update subscription status
    const { data: updatedSubscription, error } = await supabase
      .from('subscriptions')
      .update({
        status: 'cancelled',
        cancelled_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', subscription.id)
      .select()
      .single();

    if (error) throw error;

    res.json({
      status: 'success',
      message: 'Subscription cancelled successfully',
      data: { subscription: updatedSubscription }
    });
  } catch (error) {
    console.error('Cancel subscription error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to cancel subscription'
    });
  }
});

// Renew subscription
router.post('/renew', authenticate, authorize('subscriber'), async (req, res) => {
  try {
    const userId = req.user.id;
    const { paymentMethod } = req.body;

    // Get current subscription
    const { data: currentSubscription, error: getError } = await supabase
      .from('subscriptions')
      .select(`
        *,
        subscription_plans(*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (getError || !currentSubscription) {
      return res.status(404).json({
        status: 'error',
        message: 'No subscription found'
      });
    }

    // Calculate new subscription dates
    const startDate = new Date();
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 1);

    // Create new subscription
    const { data: newSubscription, error } = await supabase
      .from('subscriptions')
      .insert({
        user_id: userId,
        plan_id: currentSubscription.plan_id,
        status: 'active',
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        payment_method: paymentMethod,
        amount_paid: currentSubscription.subscription_plans.price
      })
      .select(`
        *,
        subscription_plans(*)
      `)
      .single();

    if (error) throw error;

    res.status(201).json({
      status: 'success',
      message: 'Subscription renewed successfully',
      data: { subscription: newSubscription }
    });
  } catch (error) {
    console.error('Renew subscription error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to renew subscription'
    });
  }
});

export default router;