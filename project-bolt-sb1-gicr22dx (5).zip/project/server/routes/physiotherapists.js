import express from 'express';
import { supabase } from '../config/database.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// Get all physiotherapists (public)
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      city,
      specialization,
      minRating,
      sortBy = 'rating'
    } = req.query;

    const offset = (page - 1) * limit;

    let query = supabase
      .from('physiotherapist_profiles')
      .select(`
        *,
        users!inner(
          id,
          first_name,
          last_name,
          email,
          phone,
          is_verified
        ),
        reviews(rating)
      `)
      .eq('is_approved', true)
      .eq('users.is_verified', true);

    // Apply filters
    if (city) {
      query = query.ilike('city', `%${city}%`);
    }

    if (specialization) {
      query = query.eq('specialization', specialization);
    }

    // Execute query
    const { data: physiotherapists, error, count } = await query
      .range(offset, offset + limit - 1);

    if (error) throw error;

    // Calculate ratings and filter by minimum rating
    const processedPhysiotherapists = physiotherapists
      .map(physio => {
        const ratings = physio.reviews.map(r => r.rating);
        const avgRating = ratings.length > 0 
          ? ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length 
          : 0;
        
        return {
          id: physio.id,
          userId: physio.users.id,
          name: `${physio.users.first_name} ${physio.users.last_name}`,
          email: physio.users.email,
          phone: physio.users.phone,
          specialization: physio.specialization,
          experience: physio.experience_years,
          location: `${physio.city}, ${physio.state}`,
          bio: physio.bio,
          photo: physio.profile_photo,
          rating: Number(avgRating.toFixed(1)),
          reviewCount: ratings.length,
          address: physio.address,
          qualifications: physio.qualifications,
          consultationFee: physio.consultation_fee,
          isAvailable: physio.is_available
        };
      })
      .filter(physio => !minRating || physio.rating >= parseFloat(minRating))
      .sort((a, b) => {
        switch (sortBy) {
          case 'rating':
            return b.rating - a.rating;
          case 'experience':
            return b.experience - a.experience;
          case 'name':
            return a.name.localeCompare(b.name);
          default:
            return b.rating - a.rating;
        }
      });

    res.json({
      status: 'success',
      data: {
        physiotherapists: processedPhysiotherapists,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: count,
          pages: Math.ceil(count / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get physiotherapists error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch physiotherapists'
    });
  }
});

// Get physiotherapist by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const { data: physio, error } = await supabase
      .from('physiotherapist_profiles')
      .select(`
        *,
        users!inner(
          id,
          first_name,
          last_name,
          email,
          phone,
          is_verified
        ),
        reviews(
          id,
          rating,
          comment,
          created_at,
          users!reviews_user_id_fkey(first_name, last_name)
        )
      `)
      .eq('id', id)
      .eq('is_approved', true)
      .single();

    if (error || !physio) {
      return res.status(404).json({
        status: 'error',
        message: 'Physiotherapist not found'
      });
    }

    // Calculate average rating
    const ratings = physio.reviews.map(r => r.rating);
    const avgRating = ratings.length > 0 
      ? ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length 
      : 0;

    const physiotherapist = {
      id: physio.id,
      userId: physio.users.id,
      name: `${physio.users.first_name} ${physio.users.last_name}`,
      email: physio.users.email,
      phone: physio.users.phone,
      specialization: physio.specialization,
      experience: physio.experience_years,
      location: `${physio.city}, ${physio.state}`,
      address: physio.address,
      bio: physio.bio,
      photo: physio.profile_photo,
      rating: Number(avgRating.toFixed(1)),
      reviewCount: ratings.length,
      qualifications: physio.qualifications,
      consultationFee: physio.consultation_fee,
      isAvailable: physio.is_available,
      reviews: physio.reviews.map(review => ({
        id: review.id,
        rating: review.rating,
        comment: review.comment,
        date: review.created_at,
        patientName: `${review.users.first_name} ${review.users.last_name}`
      }))
    };

    res.json({
      status: 'success',
      data: { physiotherapist }
    });
  } catch (error) {
    console.error('Get physiotherapist error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch physiotherapist'
    });
  }
});

// Update physiotherapist profile
router.put('/profile', authenticate, authorize('physiotherapist'), async (req, res) => {
  try {
    const userId = req.user.id;
    const {
      address,
      city,
      state,
      specialization,
      bio,
      consultationFee,
      isAvailable
    } = req.body;

    const { data: profile, error } = await supabase
      .from('physiotherapist_profiles')
      .update({
        address,
        city,
        state,
        specialization,
        bio,
        consultation_fee: consultationFee,
        is_available: isAvailable,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;

    res.json({
      status: 'success',
      message: 'Profile updated successfully',
      data: { profile }
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update profile'
    });
  }
});

// Get physiotherapist availability
router.get('/:id/availability', async (req, res) => {
  try {
    const { id } = req.params;
    const { date } = req.query;

    if (!date) {
      return res.status(400).json({
        status: 'error',
        message: 'Date parameter is required'
      });
    }

    // Get physiotherapist's working hours
    const { data: physio, error: physioError } = await supabase
      .from('physiotherapist_profiles')
      .select('working_hours')
      .eq('id', id)
      .single();

    if (physioError || !physio) {
      return res.status(404).json({
        status: 'error',
        message: 'Physiotherapist not found'
      });
    }

    // Get booked appointments for the date
    const { data: appointments, error: appointmentError } = await supabase
      .from('appointments')
      .select('appointment_time')
      .eq('physiotherapist_id', id)
      .eq('appointment_date', date)
      .in('status', ['confirmed', 'pending']);

    if (appointmentError) throw appointmentError;

    const bookedTimes = appointments.map(apt => apt.appointment_time);

    // Generate available time slots (simplified - you can make this more sophisticated)
    const workingHours = physio.working_hours || {
      start: '09:00',
      end: '17:00',
      slotDuration: 60
    };

    const availableSlots = [];
    const startHour = parseInt(workingHours.start.split(':')[0]);
    const endHour = parseInt(workingHours.end.split(':')[0]);

    for (let hour = startHour; hour < endHour; hour++) {
      const timeSlot = `${hour.toString().padStart(2, '0')}:00`;
      if (!bookedTimes.includes(timeSlot)) {
        availableSlots.push(timeSlot);
      }
    }

    res.json({
      status: 'success',
      data: {
        date,
        availableSlots,
        bookedSlots: bookedTimes
      }
    });
  } catch (error) {
    console.error('Get availability error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch availability'
    });
  }
});

export default router;