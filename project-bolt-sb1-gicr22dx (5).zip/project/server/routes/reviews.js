import express from 'express';
import { supabase } from '../config/database.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate, schemas } from '../middleware/validation.js';

const router = express.Router();

// Create review
router.post('/', authenticate, authorize('subscriber'), validate(schemas.review), async (req, res) => {
  try {
    const userId = req.user.id;
    const { appointmentId, rating, comment } = req.body;

    // Check if appointment exists and belongs to user
    const { data: appointment, error: appointmentError } = await supabase
      .from('appointments')
      .select('id, physiotherapist_id, status')
      .eq('id', appointmentId)
      .eq('user_id', userId)
      .single();

    if (appointmentError || !appointment) {
      return res.status(404).json({
        status: 'error',
        message: 'Appointment not found'
      });
    }

    if (appointment.status !== 'completed') {
      return res.status(400).json({
        status: 'error',
        message: 'Can only review completed appointments'
      });
    }

    // Check if review already exists
    const { data: existingReview } = await supabase
      .from('reviews')
      .select('id')
      .eq('appointment_id', appointmentId)
      .single();

    if (existingReview) {
      return res.status(409).json({
        status: 'error',
        message: 'Review already exists for this appointment'
      });
    }

    // Create review
    const { data: review, error } = await supabase
      .from('reviews')
      .insert({
        user_id: userId,
        physiotherapist_id: appointment.physiotherapist_id,
        appointment_id: appointmentId,
        rating,
        comment
      })
      .select()
      .single();

    if (error) throw error;

    res.status(201).json({
      status: 'success',
      message: 'Review created successfully',
      data: { review }
    });
  } catch (error) {
    console.error('Create review error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to create review'
    });
  }
});

// Get reviews for physiotherapist
router.get('/physiotherapist/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const { data: reviews, error, count } = await supabase
      .from('reviews')
      .select(`
        *,
        users!inner(first_name, last_name)
      `)
      .eq('physiotherapist_id', id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    // Calculate average rating
    const { data: allReviews } = await supabase
      .from('reviews')
      .select('rating')
      .eq('physiotherapist_id', id);

    const avgRating = allReviews.length > 0
      ? allReviews.reduce((sum, review) => sum + review.rating, 0) / allReviews.length
      : 0;

    res.json({
      status: 'success',
      data: {
        reviews: reviews.map(review => ({
          id: review.id,
          rating: review.rating,
          comment: review.comment,
          date: review.created_at,
          patientName: `${review.users.first_name} ${review.users.last_name}`
        })),
        averageRating: Number(avgRating.toFixed(1)),
        totalReviews: allReviews.length,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: count,
          pages: Math.ceil(count / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get reviews error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch reviews'
    });
  }
});

// Get user's reviews
router.get('/my-reviews', authenticate, async (req, res) => {
  try {
    const userId = req.user.id;
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const { data: reviews, error, count } = await supabase
      .from('reviews')
      .select(`
        *,
        physiotherapist_profiles!inner(
          id,
          specialization,
          users!inner(first_name, last_name)
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    res.json({
      status: 'success',
      data: {
        reviews,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: count,
          pages: Math.ceil(count / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get user reviews error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch reviews'
    });
  }
});

// Update review
router.put('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, comment } = req.body;
    const userId = req.user.id;

    // Check if review exists and belongs to user
    const { data: existingReview, error: getError } = await supabase
      .from('reviews')
      .select('id')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (getError || !existingReview) {
      return res.status(404).json({
        status: 'error',
        message: 'Review not found'
      });
    }

    // Update review
    const { data: review, error } = await supabase
      .from('reviews')
      .update({
        rating,
        comment,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    res.json({
      status: 'success',
      message: 'Review updated successfully',
      data: { review }
    });
  } catch (error) {
    console.error('Update review error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update review'
    });
  }
});

// Delete review
router.delete('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    // Check if review exists and belongs to user
    const { data: existingReview, error: getError } = await supabase
      .from('reviews')
      .select('id')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (getError || !existingReview) {
      return res.status(404).json({
        status: 'error',
        message: 'Review not found'
      });
    }

    // Delete review
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', id);

    if (error) throw error;

    res.json({
      status: 'success',
      message: 'Review deleted successfully'
    });
  } catch (error) {
    console.error('Delete review error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to delete review'
    });
  }
});

export default router;