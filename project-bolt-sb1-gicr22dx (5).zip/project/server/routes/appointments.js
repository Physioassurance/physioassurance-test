import express from 'express';
import { supabase } from '../config/database.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate, schemas } from '../middleware/validation.js';

const router = express.Router();

// Create appointment
router.post('/', authenticate, validate(schemas.appointment), async (req, res) => {
  try {
    const userId = req.user.id;
    const {
      physiotherapistId,
      appointmentDate,
      appointmentTime,
      notes,
      type
    } = req.body;

    // Check if user is a subscriber
    if (req.user.role !== 'subscriber') {
      return res.status(403).json({
        status: 'error',
        message: 'Only subscribers can book appointments'
      });
    }

    // Check if physiotherapist exists and is available
    const { data: physio, error: physioError } = await supabase
      .from('physiotherapist_profiles')
      .select('id, is_available, consultation_fee')
      .eq('id', physiotherapistId)
      .eq('is_approved', true)
      .single();

    if (physioError || !physio) {
      return res.status(404).json({
        status: 'error',
        message: 'Physiotherapist not found or not available'
      });
    }

    if (!physio.is_available) {
      return res.status(400).json({
        status: 'error',
        message: 'Physiotherapist is currently not available'
      });
    }

    // Check if time slot is available
    const { data: existingAppointment } = await supabase
      .from('appointments')
      .select('id')
      .eq('physiotherapist_id', physiotherapistId)
      .eq('appointment_date', appointmentDate)
      .eq('appointment_time', appointmentTime)
      .in('status', ['confirmed', 'pending'])
      .single();

    if (existingAppointment) {
      return res.status(409).json({
        status: 'error',
        message: 'Time slot is already booked'
      });
    }

    // Create appointment
    const { data: appointment, error } = await supabase
      .from('appointments')
      .insert({
        user_id: userId,
        physiotherapist_id: physiotherapistId,
        appointment_date: appointmentDate,
        appointment_time: appointmentTime,
        notes,
        type,
        status: 'pending',
        fee: physio.consultation_fee
      })
      .select(`
        *,
        physiotherapist_profiles!inner(
          id,
          users!inner(first_name, last_name, phone)
        )
      `)
      .single();

    if (error) throw error;

    res.status(201).json({
      status: 'success',
      message: 'Appointment booked successfully',
      data: { appointment }
    });
  } catch (error) {
    console.error('Create appointment error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to book appointment'
    });
  }
});

// Get user appointments
router.get('/my-appointments', authenticate, async (req, res) => {
  try {
    const userId = req.user.id;
    const { status, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let query;

    if (req.user.role === 'subscriber') {
      query = supabase
        .from('appointments')
        .select(`
          *,
          physiotherapist_profiles!inner(
            id,
            specialization,
            users!inner(first_name, last_name, phone)
          )
        `)
        .eq('user_id', userId);
    } else if (req.user.role === 'physiotherapist') {
      // Get physiotherapist profile ID
      const { data: profile } = await supabase
        .from('physiotherapist_profiles')
        .select('id')
        .eq('user_id', userId)
        .single();

      if (!profile) {
        return res.status(404).json({
          status: 'error',
          message: 'Physiotherapist profile not found'
        });
      }

      query = supabase
        .from('appointments')
        .select(`
          *,
          users!inner(first_name, last_name, phone)
        `)
        .eq('physiotherapist_id', profile.id);
    }

    if (status) {
      query = query.eq('status', status);
    }

    const { data: appointments, error, count } = await query
      .order('appointment_date', { ascending: true })
      .order('appointment_time', { ascending: true })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    res.json({
      status: 'success',
      data: {
        appointments,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: count,
          pages: Math.ceil(count / limit)
        }
      }
    });
  } catch (error) {
    console.error('Get appointments error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch appointments'
    });
  }
});

// Update appointment status
router.patch('/:id/status', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['confirmed', 'cancelled', 'completed'].includes(status)) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid status'
      });
    }

    // Get appointment
    const { data: appointment, error: getError } = await supabase
      .from('appointments')
      .select(`
        *,
        physiotherapist_profiles!inner(user_id)
      `)
      .eq('id', id)
      .single();

    if (getError || !appointment) {
      return res.status(404).json({
        status: 'error',
        message: 'Appointment not found'
      });
    }

    // Check permissions
    const canUpdate = 
      req.user.id === appointment.user_id || // Patient can cancel
      req.user.id === appointment.physiotherapist_profiles.user_id; // Physiotherapist can confirm/complete

    if (!canUpdate) {
      return res.status(403).json({
        status: 'error',
        message: 'Not authorized to update this appointment'
      });
    }

    // Update appointment
    const { data: updatedAppointment, error } = await supabase
      .from('appointments')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    res.json({
      status: 'success',
      message: 'Appointment status updated successfully',
      data: { appointment: updatedAppointment }
    });
  } catch (error) {
    console.error('Update appointment error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update appointment'
    });
  }
});

// Get appointment by ID
router.get('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;

    const { data: appointment, error } = await supabase
      .from('appointments')
      .select(`
        *,
        users!inner(first_name, last_name, phone, email),
        physiotherapist_profiles!inner(
          id,
          specialization,
          users!inner(first_name, last_name, phone, email)
        )
      `)
      .eq('id', id)
      .single();

    if (error || !appointment) {
      return res.status(404).json({
        status: 'error',
        message: 'Appointment not found'
      });
    }

    // Check permissions
    const canView = 
      req.user.id === appointment.user_id ||
      req.user.id === appointment.physiotherapist_profiles.users.id;

    if (!canView) {
      return res.status(403).json({
        status: 'error',
        message: 'Not authorized to view this appointment'
      });
    }

    res.json({
      status: 'success',
      data: { appointment }
    });
  } catch (error) {
    console.error('Get appointment error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to fetch appointment'
    });
  }
});

export default router;