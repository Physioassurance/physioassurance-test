import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

// Create transporter
const transporter = nodemailer.createTransporter({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Email templates
const emailTemplates = {
  welcome: (name) => ({
    subject: 'Welcome to Physioassurance!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0077B6;">Welcome to Physioassurance, ${name}!</h2>
        <p>Thank you for joining our platform. We're excited to help you on your healthcare journey.</p>
        <p>You can now browse and connect with qualified physiotherapists in your area.</p>
        <p>Best regards,<br>The Physioassurance Team</p>
      </div>
    `
  }),

  appointmentConfirmation: (patientName, physiotherapistName, date, time) => ({
    subject: 'Appointment Confirmation - Physioassurance',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0077B6;">Appointment Confirmed</h2>
        <p>Dear ${patientName},</p>
        <p>Your appointment has been confirmed with the following details:</p>
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Physiotherapist:</strong> ${physiotherapistName}</p>
          <p><strong>Date:</strong> ${date}</p>
          <p><strong>Time:</strong> ${time}</p>
        </div>
        <p>Please arrive 10 minutes early for your appointment.</p>
        <p>Best regards,<br>The Physioassurance Team</p>
      </div>
    `
  }),

  appointmentReminder: (patientName, physiotherapistName, date, time) => ({
    subject: 'Appointment Reminder - Tomorrow',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0077B6;">Appointment Reminder</h2>
        <p>Dear ${patientName},</p>
        <p>This is a reminder that you have an appointment tomorrow:</p>
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Physiotherapist:</strong> ${physiotherapistName}</p>
          <p><strong>Date:</strong> ${date}</p>
          <p><strong>Time:</strong> ${time}</p>
        </div>
        <p>Please arrive 10 minutes early for your appointment.</p>
        <p>Best regards,<br>The Physioassurance Team</p>
      </div>
    `
  }),

  physiotherapistApproval: (name) => ({
    subject: 'Your Physioassurance Application Has Been Approved!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0077B6;">Congratulations, Dr. ${name}!</h2>
        <p>Your application to join Physioassurance has been approved.</p>
        <p>You can now:</p>
        <ul>
          <li>Set up your profile and availability</li>
          <li>Start receiving appointment bookings</li>
          <li>Connect with patients in your area</li>
        </ul>
        <p>Welcome to the Physioassurance family!</p>
        <p>Best regards,<br>The Physioassurance Team</p>
      </div>
    `
  })
};

// Send email function
export const sendEmail = async (to, templateName, templateData = {}) => {
  try {
    const template = emailTemplates[templateName];
    if (!template) {
      throw new Error(`Email template '${templateName}' not found`);
    }

    const emailContent = typeof template === 'function' 
      ? template(...Object.values(templateData))
      : template;

    const mailOptions = {
      from: `"Physioassurance" <${process.env.EMAIL_USER}>`,
      to,
      subject: emailContent.subject,
      html: emailContent.html
    };

    const result = await transporter.sendMail(mailOptions);
    console.log('Email sent successfully:', result.messageId);
    return result;
  } catch (error) {
    console.error('Email sending failed:', error);
    throw error;
  }
};

// Verify email configuration
export const verifyEmailConfig = async () => {
  try {
    await transporter.verify();
    console.log('✅ Email configuration verified');
    return true;
  } catch (error) {
    console.error('❌ Email configuration failed:', error.message);
    return false;
  }
};