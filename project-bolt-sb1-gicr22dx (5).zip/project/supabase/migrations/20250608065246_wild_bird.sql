/*
  # Insert Sample Data for Physioassurance

  1. Sample subscription plans
  2. Sample users (physiotherapists and subscribers)
  3. Sample physiotherapist profiles
  4. Sample appointments and reviews
*/

-- Insert subscription plans
INSERT INTO subscription_plans (name, description, price, features, max_appointments) VALUES
('Basic', 'Perfect for occasional needs', 499.00, '["2 appointments per month", "Access to basic search", "Email support", "Limited provider options"]', 2),
('Standard', 'Most popular for regular care', 999.00, '["5 appointments per month", "Advanced search filters", "Priority booking", "Chat with physiotherapists", "Phone & email support"]', 5),
('Premium', 'For comprehensive care needs', 1999.00, '["Unlimited appointments", "Home visit options", "24/7 support access", "Family account (up to 4 members)", "Exclusive health resources"]', -1);

-- Insert sample users (physiotherapists)
INSERT INTO users (email, password, first_name, last_name, phone, role, is_verified) VALUES
('tahir.khan@physioassurance.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAVyRai', 'Tahir', 'Khan', '+91-9876543210', 'physiotherapist', true),
('sameena.t@physioassurance.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAVyRai', 'Sameena', 'T', '+91-9876543211', 'physiotherapist', true),
('priya.patel@physioassurance.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAVyRai', 'Priya', 'Patel', '+91-9876543212', 'physiotherapist', true);

-- Insert sample users (subscribers)
INSERT INTO users (email, password, first_name, last_name, phone, role, is_verified) VALUES
('vikram.singh@example.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAVyRai', 'Vikram', 'Singh', '+91-9876543213', 'subscriber', true),
('meera.joshi@example.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAVyRai', 'Meera', 'Joshi', '+91-9876543214', 'subscriber', true),
('rohit.patel@example.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAVyRai', 'Rohit', 'Patel', '+91-9876543215', 'subscriber', true);

-- Insert physiotherapist profiles
INSERT INTO physiotherapist_profiles (
  user_id, 
  address, 
  city, 
  state, 
  specialization, 
  experience_years, 
  qualifications, 
  bio, 
  profile_photo,
  consultation_fee,
  is_approved
) VALUES
(
  (SELECT id FROM users WHERE email = 'tahir.khan@physioassurance.com'),
  '123 Medical Center, Bandra West',
  'Mumbai',
  'Maharashtra',
  'Orthopedic Physiotherapy',
  8,
  'BPT, MPT (Orthopedics), Certified Manual Therapist',
  'Specializing in sports injuries and post-surgery rehabilitation with a focus on evidence-based treatments and personalized care plans.',
  'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  800.00,
  true
),
(
  (SELECT id FROM users WHERE email = 'sameena.t@physioassurance.com'),
  '456 Neuro Clinic, Connaught Place',
  'Delhi',
  'Delhi',
  'Neurological Rehabilitation',
  12,
  'BPT, MPT (Neurology), PhD in Rehabilitation Sciences',
  'Expert in treating neurological conditions including stroke recovery, Parkinson''s disease, and multiple sclerosis with holistic approaches.',
  'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  1000.00,
  true
),
(
  (SELECT id FROM users WHERE email = 'priya.patel@physioassurance.com'),
  '789 Sports Rehab Center, Koramangala',
  'Bangalore',
  'Karnataka',
  'Sports Physiotherapy',
  6,
  'BPT, MPT (Sports), Certified Strength & Conditioning Specialist',
  'Former athlete turned physiotherapist specializing in sports injury prevention and rehabilitation for athletes of all levels.',
  'https://images.pexels.com/photos/5407247/pexels-photo-5407247.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  700.00,
  true
);

-- Insert sample subscriptions
INSERT INTO subscriptions (user_id, plan_id, status, start_date, end_date, payment_method, amount_paid) VALUES
(
  (SELECT id FROM users WHERE email = 'vikram.singh@example.com'),
  (SELECT id FROM subscription_plans WHERE name = 'Standard'),
  'active',
  '2024-01-01',
  '2024-02-01',
  'credit_card',
  999.00
),
(
  (SELECT id FROM users WHERE email = 'meera.joshi@example.com'),
  (SELECT id FROM subscription_plans WHERE name = 'Premium'),
  'active',
  '2024-01-15',
  '2024-02-15',
  'upi',
  1999.00
);

-- Insert sample appointments
INSERT INTO appointments (
  user_id, 
  physiotherapist_id, 
  appointment_date, 
  appointment_time, 
  status, 
  type, 
  notes, 
  fee
) VALUES
(
  (SELECT id FROM users WHERE email = 'vikram.singh@example.com'),
  (SELECT id FROM physiotherapist_profiles WHERE user_id = (SELECT id FROM users WHERE email = 'tahir.khan@physioassurance.com')),
  '2024-01-20',
  '10:00',
  'completed',
  'consultation',
  'Knee pain after football injury',
  800.00
),
(
  (SELECT id FROM users WHERE email = 'meera.joshi@example.com'),
  (SELECT id FROM physiotherapist_profiles WHERE user_id = (SELECT id FROM users WHERE email = 'sameena.t@physioassurance.com')),
  '2024-01-22',
  '14:00',
  'completed',
  'treatment',
  'Chronic back pain management',
  1000.00
),
(
  (SELECT id FROM users WHERE email = 'rohit.patel@example.com'),
  (SELECT id FROM physiotherapist_profiles WHERE user_id = (SELECT id FROM users WHERE email = 'priya.patel@physioassurance.com')),
  '2024-01-25',
  '11:00',
  'confirmed',
  'consultation',
  'Shoulder mobility issues',
  700.00
);

-- Insert sample reviews
INSERT INTO reviews (user_id, physiotherapist_id, appointment_id, rating, comment) VALUES
(
  (SELECT id FROM users WHERE email = 'vikram.singh@example.com'),
  (SELECT id FROM physiotherapist_profiles WHERE user_id = (SELECT id FROM users WHERE email = 'tahir.khan@physioassurance.com')),
  (SELECT id FROM appointments WHERE user_id = (SELECT id FROM users WHERE email = 'vikram.singh@example.com') LIMIT 1),
  5,
  'Excellent treatment! Dr. Tahir was very professional and helped me recover quickly from my knee injury. Highly recommended!'
),
(
  (SELECT id FROM users WHERE email = 'meera.joshi@example.com'),
  (SELECT id FROM physiotherapist_profiles WHERE user_id = (SELECT id FROM users WHERE email = 'sameena.t@physioassurance.com')),
  (SELECT id FROM appointments WHERE user_id = (SELECT id FROM users WHERE email = 'meera.joshi@example.com') LIMIT 1),
  4,
  'Very knowledgeable and experienced. The treatment plan was comprehensive and I''m seeing good progress with my back pain.'
);