/*
  # Physioassurance Database Schema

  1. New Tables
    - `users` - Store user accounts (subscribers and physiotherapists)
    - `physiotherapist_profiles` - Extended profile data for physiotherapists
    - `subscription_plans` - Available subscription plans
    - `subscriptions` - User subscriptions
    - `appointments` - Appointment bookings
    - `reviews` - Patient reviews for physiotherapists

  2. Security
    - Enable RLS on all tables
    - Add appropriate policies for each user role
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  password text NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  phone text,
  role text NOT NULL CHECK (role IN ('subscriber', 'physiotherapist', 'admin')),
  is_verified boolean DEFAULT false,
  last_login timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create physiotherapist profiles table
CREATE TABLE IF NOT EXISTS physiotherapist_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  pincode text,
  specialization text NOT NULL,
  experience_years integer NOT NULL,
  qualifications text NOT NULL,
  bio text NOT NULL,
  profile_photo text,
  consultation_fee decimal(10,2) DEFAULT 500.00,
  is_available boolean DEFAULT true,
  is_approved boolean DEFAULT false,
  working_hours jsonb DEFAULT '{"start": "09:00", "end": "17:00", "slotDuration": 60}',
  documents jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create subscription plans table
CREATE TABLE IF NOT EXISTS subscription_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  duration_months integer DEFAULT 1,
  features jsonb DEFAULT '[]',
  max_appointments integer,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  plan_id uuid REFERENCES subscription_plans(id),
  status text NOT NULL CHECK (status IN ('active', 'cancelled', 'expired')),
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  payment_method text,
  amount_paid decimal(10,2) NOT NULL,
  cancelled_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  physiotherapist_id uuid REFERENCES physiotherapist_profiles(id) ON DELETE CASCADE,
  appointment_date date NOT NULL,
  appointment_time time NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  type text NOT NULL CHECK (type IN ('consultation', 'treatment', 'follow-up')),
  notes text,
  fee decimal(10,2),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(physiotherapist_id, appointment_date, appointment_time)
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  physiotherapist_id uuid REFERENCES physiotherapist_profiles(id) ON DELETE CASCADE,
  appointment_id uuid REFERENCES appointments(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(appointment_id)
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE physiotherapist_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Users policies
CREATE POLICY "Users can read own data" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
  FOR UPDATE USING (auth.uid() = id);

-- Physiotherapist profiles policies
CREATE POLICY "Anyone can read approved physiotherapist profiles" ON physiotherapist_profiles
  FOR SELECT USING (is_approved = true);

CREATE POLICY "Physiotherapists can read own profile" ON physiotherapist_profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Physiotherapists can update own profile" ON physiotherapist_profiles
  FOR UPDATE USING (auth.uid() = user_id);

-- Subscription plans policies
CREATE POLICY "Anyone can read active subscription plans" ON subscription_plans
  FOR SELECT USING (is_active = true);

-- Subscriptions policies
CREATE POLICY "Users can read own subscriptions" ON subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own subscriptions" ON subscriptions
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own subscriptions" ON subscriptions
  FOR UPDATE USING (auth.uid() = user_id);

-- Appointments policies
CREATE POLICY "Users can read own appointments" ON appointments
  FOR SELECT USING (
    auth.uid() = user_id OR 
    auth.uid() = (SELECT user_id FROM physiotherapist_profiles WHERE id = physiotherapist_id)
  );

CREATE POLICY "Subscribers can create appointments" ON appointments
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own appointments" ON appointments
  FOR UPDATE USING (
    auth.uid() = user_id OR 
    auth.uid() = (SELECT user_id FROM physiotherapist_profiles WHERE id = physiotherapist_id)
  );

-- Reviews policies
CREATE POLICY "Anyone can read reviews" ON reviews
  FOR SELECT USING (true);

CREATE POLICY "Users can create reviews for their appointments" ON reviews
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reviews" ON reviews
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own reviews" ON reviews
  FOR DELETE USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_physiotherapist_profiles_user_id ON physiotherapist_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_physiotherapist_profiles_city ON physiotherapist_profiles(city);
CREATE INDEX IF NOT EXISTS idx_physiotherapist_profiles_specialization ON physiotherapist_profiles(specialization);
CREATE INDEX IF NOT EXISTS idx_physiotherapist_profiles_approved ON physiotherapist_profiles(is_approved);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_appointments_user_id ON appointments(user_id);
CREATE INDEX IF NOT EXISTS idx_appointments_physiotherapist_id ON appointments(physiotherapist_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);
CREATE INDEX IF NOT EXISTS idx_reviews_physiotherapist_id ON reviews(physiotherapist_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user_id ON reviews(user_id);