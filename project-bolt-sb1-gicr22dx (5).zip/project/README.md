# Physioassurance - Complete Healthcare Platform

A comprehensive platform connecting subscribers with qualified physiotherapists across India.

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn
- Supabase account (for database)

### Installation

1. **Clone or extract the project**
   ```bash
   # If you downloaded a zip file, extract it first
   cd physioassurance-website
   ```

2. **Install all dependencies**
   ```bash
   npm run setup
   ```
   This will install dependencies for both frontend and backend.

3. **Set up environment variables**
   ```bash
   # Copy the example file
   cp server/.env.example server/.env
   ```
   
   Then edit `server/.env` with your actual values:
   ```env
   PORT=5000
   NODE_ENV=development
   
   # Supabase Configuration
   SUPABASE_URL=your_supabase_url
   SUPABASE_ANON_KEY=your_supabase_anon_key
   SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
   
   # JWT Configuration
   JWT_SECRET=your_jwt_secret_key
   JWT_EXPIRES_IN=7d
   
   # Frontend URL
   FRONTEND_URL=http://localhost:5173
   ```

4. **Set up the database**
   - Go to your Supabase dashboard
   - Run the SQL migrations from `supabase/migrations/` folder
   - This will create all necessary tables and sample data

5. **Start the development servers**
   
   **Option 1: Run both frontend and backend together**
   ```bash
   npm run dev:full
   ```
   
   **Option 2: Run them separately**
   ```bash
   # Terminal 1 - Frontend (React)
   npm run dev:frontend
   
   # Terminal 2 - Backend (Node.js)
   npm run dev:backend
   ```

### 🌐 Access the Application

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5000
- **API Health Check**: http://localhost:5000/health

## 📁 Project Structure

```
physioassurance-website/
├── src/                    # React frontend
│   ├── components/         # Reusable components
│   ├── pages/             # Page components
│   ├── types/             # TypeScript types
│   └── data/              # Mock data
├── server/                # Node.js backend
│   ├── routes/            # API routes
│   ├── middleware/        # Express middleware
│   ├── config/            # Database config
│   └── utils/             # Utility functions
├── supabase/              # Database migrations
└── public/                # Static assets
```

## 🔧 Development

### Frontend Development
The frontend is built with:
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Framer Motion** for animations
- **React Router** for navigation
- **Lucide React** for icons

### Backend Development
The backend includes:
- **Node.js + Express** REST API
- **Supabase** PostgreSQL database
- **JWT** authentication
- **File upload** with Cloudinary
- **Email** notifications
- **Rate limiting** and security

### Available Scripts

```bash
# Frontend only
npm run dev:frontend      # Start React dev server
npm run build            # Build for production
npm run preview          # Preview production build

# Backend only
npm run dev:backend      # Start Node.js dev server

# Full stack
npm run dev:full         # Start both servers
npm run setup           # Install all dependencies
```

## 🗃️ Database Setup

1. **Create a Supabase project** at https://supabase.com
2. **Get your credentials** from Project Settings > API
3. **Run the migrations**:
   - Copy the SQL from `supabase/migrations/20250608065223_odd_jungle.sql`
   - Paste and run in Supabase SQL Editor
   - Copy the SQL from `supabase/migrations/20250608065246_wild_bird.sql`
   - Paste and run in Supabase SQL Editor

This will create:
- User accounts table
- Physiotherapist profiles
- Appointment system
- Review system
- Subscription management
- Sample data for testing

## 🔐 Authentication

The app supports:
- **Subscriber registration/login**
- **Physiotherapist registration/login**
- **JWT-based authentication**
- **Role-based access control**

## 📱 Features

### For Subscribers
- Find physiotherapists by location and specialization
- Book appointments online
- Rate and review physiotherapists
- Manage subscription plans
- View appointment history

### For Physiotherapists
- Create professional profiles
- Manage availability and appointments
- Receive patient reviews
- Track earnings and analytics
- Upload credentials and certificates

### For Admins
- Approve physiotherapist applications
- Manage users and content
- View platform analytics
- Handle support requests

## 🚨 Troubleshooting

### Common Issues

1. **"Module not found" errors**
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   cd server && rm -rf node_modules package-lock.json && npm install
   ```

2. **Port already in use**
   ```bash
   # Kill processes on ports 5173 and 5000
   npx kill-port 5173 5000
   ```

3. **Database connection issues**
   - Check your Supabase credentials in `server/.env`
   - Ensure migrations have been run
   - Verify your Supabase project is active

4. **CORS errors**
   - Make sure backend is running on port 5000
   - Check FRONTEND_URL in server/.env matches your frontend URL

### Getting Help

If you encounter issues:
1. Check the console for error messages
2. Verify all environment variables are set
3. Ensure both frontend and backend servers are running
4. Check that database migrations have been applied

## 📄 License

This project is licensed under the MIT License.