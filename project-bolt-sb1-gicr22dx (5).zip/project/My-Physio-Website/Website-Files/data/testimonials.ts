import { Testimonial } from '../types/testimonial';

export const testimonials: Testimonial[] = [
  {
    name: "Vikram Singh",
    location: "Mumbai, Maharashtra",
    rating: 5,
    content: "After my knee surgery, I was struggling with mobility. Through Physioassurance, I found an amazing physiotherapist who created a personalized recovery plan. Now I'm back to my active lifestyle!",
    avatar: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    name: "Meera Joshi",
    location: "Delhi, NCR",
    rating: 4,
    content: "As someone with chronic back pain, finding the right physiotherapist was crucial. The platform made it easy to compare specialists and read reviews. My physiotherapist has been a game-changer for my quality of life.",
    avatar: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    name: "Rohit Patel",
    location: "Bangalore, Karnataka",
    rating: 5,
    content: "The convenience of booking appointments through the app and having my treatment history in one place has made managing my physiotherapy sessions so much easier. Highly recommend Physioassurance!",
    avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
];