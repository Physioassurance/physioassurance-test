import { Physiotherapist } from '../types/physiotherapist';

export const featuredmalePhysiotherapists: Physiotherapist[] = [
  {
    id: 1,
    name: "Dr. SAVANI DOSHI (PT)",
    specialization: "Orthopedic Physiotherapy",
    experience: 8,
    location: "Mumbai, Maharashtra",
    bio: "Specializing in sports injuries and post-surgery rehabilitation with a focus on evidence-based treatments and personalized care plans.",
    photo: "https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 4.9,
    reviewCount: 124
  },
  {
    id: 2,
    name: "Dr. SUKRITI (PT)",
    specialization: "Neurological Rehabilitation",
    experience: 12,
    location: "Delhi, NCR",
    bio: "Expert in treating neurological conditions including stroke recovery, Parkinson's disease, and multiple sclerosis with holistic approaches.",
    photo: "https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 4.8,
    reviewCount: 98
  },
  {
    id: 3,
    name: "Dr.  Tahir Khan (PT)",
    specialization: "Sports Physiotherapy",
    experience: 6,
    location: "Bangalore, Karnataka",
    bio: "Former athlete turned physiotherapist specializing in sports injury prevention and rehabilitation for athletes of all levels.",
    photo: "https://images.pexels.com/photos/5407247/pexels-photo-5407247.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 4.7,
    reviewCount: 87
  }
];