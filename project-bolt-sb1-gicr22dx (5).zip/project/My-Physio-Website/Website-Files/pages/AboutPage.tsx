import React from 'react';
import { motion } from 'framer-motion';
import { Users, Award, Clock, MapPin, CheckCircle, Heart } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <>
      {/* Hero section */}
      <section className="pt-32 pb-16 md:pb-24 bg-blue-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight mb-6">
                About Physioassurance
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                We're on a mission to make quality physiotherapy accessible to everyone in India.
              </p>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center">
                  <Users className="h-5 w-5 text-blue-600 mr-2" />
                  <span className="text-gray-700">200+ Physiotherapists</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-blue-600 mr-2" />
                  <span className="text-gray-700">50+ Cities</span>
                </div>
                <div className="flex items-center">
                  <Award className="h-5 w-5 text-blue-600 mr-2" />
                  <span className="text-gray-700">10+ Years Experience</span>
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
              className="hidden lg:block"
            >
              <img 
                src="https://images.pexels.com/photos/8942991/pexels-photo-8942991.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Physiotherapy session" 
                className="rounded-lg shadow-xl w-full h-auto"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our story */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Story</h2>
              <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <p className="text-lg text-gray-600 mb-6">
                Physioassurance was founded by Dr. MOHAMMAD SHOAIB.T (PT), a renowned physiotherapist, who recognized a significant gap in India's healthcare system.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Despite a growing need for physiotherapy services, many patients struggled to find qualified professionals in their area. Meanwhile, skilled physiotherapists found it challenging to establish their practice and connect with patients who needed their expertise.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Dr. MOHAMMAD SHOAIB.T (PT) envisioned a platform that would bridge this gap – connecting patients with verified physiotherapists while helping professionals grow their practice. This vision led to the birth of Physioassurance.
              </p>
              <p className="text-lg text-gray-600">
                Today, Physioassurance has grown into India's leading physiotherapy network, connecting thousands of patients with qualified professionals across the country. Our mission remains the same: to make quality physiotherapy accessible to everyone who needs it.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission and vision */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-lg shadow-md"
            >
              <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                <Heart className="h-6 w-6 text-blue-600 mr-2" />
                Our Mission
              </h3>
              <p className="text-gray-600 mb-4">
                To connect patients with the physiotherapists in their area, ensuring quality care and faster recovery through personalized treatment plans.
              </p>
              <ul className="space-y-3">
                {[
                  "Make quality physiotherapy accessible across India",
                  "Empower physiotherapists to grow their practice",
                  "Improve patient outcomes through personalized care",
                  "Streamline the process of finding and booking appointments"
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-lg shadow-md"
            >
              <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                <Award className="h-6 w-6 text-blue-600 mr-2" />
                Our Vision
              </h3>
              <p className="text-gray-600 mb-4">
                To be India's premier platform for physiotherapy services, transforming how patients receive care and how professionals deliver their expertise.
              </p>
              <ul className="space-y-3">
                {[
                  "Create the largest network of verified physiotherapists in India",
                  "Introduce innovative technologies to enhance patient care",
                  "Establish new standards of quality in physiotherapy services",
                  "Make preventive physiotherapy a part of everyday wellness"
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our values */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Core Values</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These principles guide everything we do at Physioassurance
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Quality",
                description: "We ensure all physiotherapists on our platform are verified professionals with the right qualifications and expertise.",
                icon: <Award className="h-10 w-10 text-blue-600" />
              },
              {
                title: "Accessibility",
                description: "We're committed to making quality physiotherapy services available to everyone, regardless of location.",
                icon: <MapPin className="h-10 w-10 text-blue-600" />
              },
              {
                title: "Innovation",
                description: "We continuously explore new technologies and approaches to enhance the physiotherapy experience.",
                icon: <Users className="h-10 w-10 text-blue-600" />
              },
              {
                title: "Transparency",
                description: "We believe in clear communication about services, pricing, and expectations for both patients and professionals.",
                icon: <Heart className="h-10 w-10 text-blue-600" />
              },
              {
                title: "Patient-Centered Care",
                description: "We prioritize patient needs and outcomes in everything we do, ensuring personalized care plans.",
                icon: <Heart className="h-10 w-10 text-blue-600" />
              },
              {
                title: "Professional Growth",
                description: "We support the development and success of physiotherapists through our platform and resources.",
                icon: <Award className="h-10 w-10 text-blue-600" />
              }
            ].map((value, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-lg shadow-md text-center"
              >
                <div className="flex justify-center mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Meet Our Leadership Team</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              The experienced professionals guiding Physioassurance's mission
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                name: "Dr. MOHAMMAD SHOAIB.T",
                title: "Founder & CEO",
                bio: "A renowned physiotherapist with well experience in rehabilitation.",
                image: "jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              },
              {
                name: "Dr. ANASHWARA MANOJ",
                title: "physiotherapist",
                bio: "Specialist in neurological physiotherapy with extensive research experience.",
                image: "https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              },
              {
                name: "KEVIN",
                title: "Chief Technology Officer",
                bio: "Tech innovator with a passion for healthcare solutions and digital transformation.",
                image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              },
              {
                name: "PANNAG VAIDYA",
                title: "Head of Operations",
                bio: "Expert in healthcare management with a focus on scaling quality services.",
                image: "https://images.pexels.com/photos/3778603/pexels-photo-3778603.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              }
            ].map((member, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg overflow-hidden shadow-md"
              >
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">{member.name}</h3>
                  <p className="text-blue-600 mb-3">{member.title}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Achievements</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Milestones we've reached in our journey
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-gray-50 p-8 rounded-lg"
            >
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Growth & Impact</h3>
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <Users className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">5,000+</p>
                    <p className="text-gray-600">Patients helped</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <MapPin className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">50+</p>
                    <p className="text-gray-600">Cities covered</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <Award className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">200+</p>
                    <p className="text-gray-600">Verified physiotherapists</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <Clock className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">20,000+</p>
                    <p className="text-gray-600">Appointments facilitated</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-gray-50 p-8 rounded-lg"
            >
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Recognition & Awards</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <Award className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Healthcare Startup of the Year 2022</p>
                    <p className="text-gray-600">Indian Healthcare Innovation Awards</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <Award className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Best Healthcare Platform 2021</p>
                    <p className="text-gray-600">Digital India Awards</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <Award className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Featured in Economic Times</p>
                    <p className="text-gray-600">"Transforming Physiotherapy in India"</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                      <Award className="h-6 w-6" />
                    </div>
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Top 50 Healthcare Startups 2020</p>
                    <p className="text-gray-600">Inc. India</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;