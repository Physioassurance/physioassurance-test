import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-white z-0">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/3775156/pexels-photo-3775156.jpeg?auto=compress&cs=tinysrgb&w=1600')] bg-cover bg-center opacity-10"></div>
      </div>

      <div className="container relative mx-auto px-4 md:px-6 z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Connect With Expert Physiotherapists Near You
              </h1>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <p className="text-xl text-gray-600 mb-8 max-w-lg">
                Physioassurance helps you find the right physiotherapist for your needs, ensuring quality care and faster recovery.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white p-2 rounded-lg shadow-lg flex flex-col sm:flex-row mb-8 max-w-xl"
            >
              <div className="flex-grow p-2">
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">Your Location</label>
                <div className="relative">
                  <input
                    type="text"
                    id="location"
                    placeholder="Enter your city or area"
                    className="w-full py-2 pl-10 pr-4 rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500 shadow-sm"
                  />
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
              </div>
              <button className="mt-3 sm:mt-0 sm:ml-3 flex-shrink-0 px-6 py-3 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">
                Find Physiotherapists
              </button>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-wrap gap-4 items-center"
            >
              <Link 
                to="/subscriber" 
                className="inline-flex items-center justify-center rounded-md bg-blue-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Get Started
              </Link>
              <Link 
                to="/about" 
                className="inline-flex items-center justify-center rounded-md border border-gray-300 bg-white px-6 py-3 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Learn More
              </Link>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className="hidden lg:block"
          >
            <img 
              src="https://images.pexels.com/photos/7088528/pexels-photo-7088528.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Physiotherapist helping a patient" 
              className="rounded-lg shadow-xl w-full h-auto"
            />
          </motion.div>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="p-4"
          >
            <p className="text-3xl font-bold text-blue-600 mb-1">200+</p>
            <p className="text-gray-600">Qualified Physiotherapists</p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="p-4"
          >
            <p className="text-3xl font-bold text-blue-600 mb-1">50+</p>
            <p className="text-gray-600">Cities Covered</p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="p-4"
          >
            <p className="text-3xl font-bold text-blue-600 mb-1">5,000+</p>
            <p className="text-gray-600">Happy Patients</p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="p-4"
          >
            <p className="text-3xl font-bold text-blue-600 mb-1">4.8/5</p>
            <p className="text-gray-600">Average Rating</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;