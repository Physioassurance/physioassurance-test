import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-100">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <Heart className="h-6 w-6 text-blue-400" />
              <span className="text-xl font-bold tracking-tight text-white">
                Physioassurance
              </span>
            </Link>
            <p className="text-gray-400 text-sm">
              "Empowering Recovery,Discover Wellness Close to Home!".
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white text-sm">Home</Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white text-sm">About Us</Link>
              </li>
              <li>
                <Link to="/physiotherapist" className="text-gray-400 hover:text-white text-sm">For Physiotherapists</Link>
              </li>
              <li>
                <Link to="/subscriber" className="text-gray-400 hover:text-white text-sm">For Subscribers</Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-white text-sm">Contact Us</Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Services</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm">Find a Physiotherapist</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm">Subscription Plans</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm">Become a Provider</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm">Appointment Booking</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white text-sm">Recovery Resources</a>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-start space-x-2">
                <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                <span className="text-gray-400 text-sm">153 U.K.T. HILLS, HUBLI, India</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400 text-sm">+91 636 327 7809</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400 text-sm">physioassurance@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-400">
              © {new Date().getFullYear()} Physioassurance. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="#" className="text-sm text-gray-400 hover:text-white">Privacy Policy</Link>
              <Link to="#" className="text-sm text-gray-400 hover:text-white">Terms of Service</Link>
              <Link to="#" className="text-sm text-gray-400 hover:text-white">Cookie Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;