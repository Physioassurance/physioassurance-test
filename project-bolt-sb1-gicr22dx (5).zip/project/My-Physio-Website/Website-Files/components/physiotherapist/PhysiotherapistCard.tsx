import React from 'react';
import { motion } from 'framer-motion';
import { Star, MapPin, Phone, Calendar } from 'lucide-react';
import { Physiotherapist } from '../../types/physiotherapist';

interface PhysiotherapistCardProps {
  therapist: Physiotherapist;
  delay?: number;
}

const PhysiotherapistCard: React.FC<PhysiotherapistCardProps> = ({ therapist, delay = 0 }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true }}
      className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
    >
      <div className="relative h-48">
        <img 
          src={therapist.photo} 
          alt={therapist.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
            <span className="text-white text-sm font-medium">{therapist.rating}</span>
            <span className="text-gray-200 text-sm">({therapist.reviewCount} reviews)</span>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-1">{therapist.name}</h3>
        <p className="text-blue-600 mb-3">{therapist.specialization}</p>
        
        <div className="flex items-center text-gray-500 mb-2">
          <MapPin className="h-4 w-4 mr-2" />
          <span className="text-sm">{therapist.location}</span>
        </div>
        
        <div className="flex items-center text-gray-500 mb-4">
          <Calendar className="h-4 w-4 mr-2" />
          <span className="text-sm">{therapist.experience} years experience</span>
        </div>
        
        <p className="text-gray-600 text-sm mb-6 line-clamp-2">{therapist.bio}</p>
        
        <div className="flex space-x-2">
          <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
            Book Appointment
          </button>
          <button className="flex items-center justify-center border border-blue-600 text-blue-600 p-2 rounded-md hover:bg-blue-50 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
            <Phone className="h-5 w-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default PhysiotherapistCard;