export interface Physiotherapist {
  id: number;
  name: string;
  specialization: string;
  experience: number;
  location: string;
  bio: string;
  photo: string;
  rating: number;
  reviewCount: number;
}