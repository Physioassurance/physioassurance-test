export interface Testimonial {
  name: string;
  location: string;
  rating: number;
  content: string;
  avatar: string;
}