#!/bin/bash

echo ""
echo "========================================"
echo "   PHYSIOASSURANCE WEBSITE - START HERE"
echo "========================================"
echo ""
echo "This will set up and start your website..."
echo ""
echo "After starting, your website will be available at:"
echo "  - Local: http://localhost:5173"
echo "  - Network: http://YOUR-IP-ADDRESS:5173"
echo ""
read -p "Press Enter to continue..."

echo "Installing website files..."
npm run setup

echo ""
echo "Starting your website..."
echo ""
echo "============================================"
echo "   YOUR WEBSITE IS STARTING..."
echo "============================================"
echo ""
echo "Open your browser and go to:"
echo "  http://localhost:5173"
echo ""
echo "To share with others on same WiFi:"
echo "  1. Find your IP address"
echo "  2. Share: http://YOUR-IP:5173"
echo ""
echo "Press Ctrl+C to stop the website"
echo "============================================"
echo ""

npm run start-website