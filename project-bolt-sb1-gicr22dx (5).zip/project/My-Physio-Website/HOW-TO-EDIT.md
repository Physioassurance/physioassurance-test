# 🎨 How to Edit Your Physioassurance Website

## 📁 **Important Folders:**

```
📁 My-Physio-Website/
├── 📁 Website-Files/          ← Your website pages are here
│   ├── 📁 pages/             ← Main pages (Home, About, Contact, etc.)
│   ├── 📁 components/        ← Reusable parts (Header, Footer, etc.)
│   └── 📁 data/             ← Content like testimonials, doctors info
├── 📄 START-HERE.bat         ← Double-click this to start (Windows)
├── 📄 START-HERE.sh          ← Double-click this to start (Mac/Linux)
└── 📄 HOW-TO-EDIT.md        ← This file
```

## 🚀 **Quick Start:**

### Step 1: Start Your Website
- **Windows:** Double-click `START-HERE.bat`
- **Mac/Linux:** Double-click `START-HERE.sh`

### Step 2: Open for Editing
1. **Download VS Code** (free): https://code.visualstudio.com
2. **Open VS Code**
3. **File → Open Folder** → Choose `My-Physio-Website`
4. **Start editing!**

## ✏️ **What You Can Edit:**

### 🏠 **Home Page**
- **File:** `Website-Files/pages/HomePage.tsx`
- **Change:** Main text, images, testimonials

### 📞 **Contact Information**
- **File:** `Website-Files/pages/ContactPage.tsx`
- **Change:** Phone numbers, email, address

### 👨‍⚕️ **Doctor Profiles**
- **File:** `Website-Files/data/physiotherapists.ts`
- **Change:** Doctor names, photos, specializations

### 🗣️ **Customer Reviews**
- **File:** `Website-Files/data/testimonials.ts`
- **Change:** Customer names, reviews, photos

### 🎨 **Colors and Styling**
- **File:** `Website-Files/index.css`
- **Change:** Colors, fonts, spacing

## 🔧 **Common Edits:**

### Change Website Title
**File:** `index.html`
```html
<title>Your New Title Here</title>
```

### Change Company Name
**File:** `Website-Files/components/layout/Navbar.tsx`
Look for "Physioassurance" and replace with your name

### Change Phone Number
**File:** `Website-Files/components/layout/Footer.tsx`
Look for "+91 636 327 7809" and replace

### Add Your Logo
1. Put your logo image in `public/` folder
2. **File:** `Website-Files/components/layout/Navbar.tsx`
3. Replace the Heart icon with your logo

## 💡 **Tips:**

1. **Save your changes** - Press `Ctrl+S` (Windows) or `Cmd+S` (Mac)
2. **See changes instantly** - Your website updates automatically
3. **Backup your work** - Copy the folder before making big changes
4. **Start simple** - Change text first, then try images and colors

## 🆘 **Need Help?**

- **Website not starting?** Make sure you have internet connection
- **Can't see changes?** Refresh your browser (F5)
- **Broke something?** Copy the original folder back

## 📱 **Your Website Will Work On:**
- ✅ Desktop computers
- ✅ Tablets
- ✅ Mobile phones
- ✅ All modern browsers

Happy editing! 🎉